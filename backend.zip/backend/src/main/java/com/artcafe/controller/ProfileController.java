package com.artcafe.controller;

public class ProfileController {
    
}
